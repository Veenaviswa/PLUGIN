<!-- <?php
/**
*plugin Name:Idea Pro Example plugin
**/
function ideapro_example_function()
{
  // $information="This is a very basic plugin.";
  // return $information;
  $content.="<p>this is a very basic plugin.</p>";
  $content.="<div>this is a div</div>";
return $content;
}
add_shortcode('example','ideapro_example_function');
?>
 -->